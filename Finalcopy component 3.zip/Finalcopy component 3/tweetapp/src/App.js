import React, { Component } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import Login from "./components/login.component";
import RegisterComponent from './components/RegisterComponent';
import HomeComponent from './components/HomeComponent';
import UserList from './components/UserList';
import ViewTweets from './components/ViewTweets';
import PostComponent from './components/PostComponent';
import UpdateTweetComponent from './components/UpdateTweetComponent';
import ForgotPassword from './components/ForgotPasswordComponent';
import ViewTweetsHome from './components/ViewTweetsHome';
import MyTweetComponent from './components/MyTweetComponent';
import search from './components/Search';
import HeaderComponent from './components/HeaderComponent';

class App extends Component {
  render() {

  
  return (<Router>
    <div className="App">


      <div className="auth-wrapper">
        <div className="auth-inner">
          <Switch>
          
            <Route exact path='/' component={ViewTweetsHome} />
            <Route path="/login" component={Login} />
            <Route path="/register" component={RegisterComponent} />
            <Route path="/home" component={HomeComponent} />
            <Route path="/allUser" component={UserList} />
            <Route path="/allTweet" component={ViewTweets} />
            <Route path="/postTweet" component={PostComponent} />
            <Route path="/updateTweet" component={UpdateTweetComponent} />
            <Route path="/forgot" component={ForgotPassword} />
            <Route path="/viewTweetshome" component={ViewTweetsHome} />
            <Route path="/myTweet" component={MyTweetComponent} />
            <Route path="/search" component={search} />
            <Route path="/header" component={HeaderComponent} />
            
          </Switch>
        </div>
      </div>
    </div></Router> 
  );
}
}
export default App;