package com.iiht.tweetapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.repository.ViewTweetRepository;
import com.iiht.tweetapp.service.ViewTweetService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class ViewTweetController {

	@Autowired
	ViewTweetService viewTweetService;
	
	@Autowired
	ViewTweetRepository viewTweetRepository;
	
	@GetMapping("/all")
	public @ResponseBody Iterable<TweetUser> viewAll() {
		return viewTweetService.viewAllTweet();
		
	}
	
	
	@GetMapping("/{username}/all")
	public ResponseEntity<List<TweetUser>> viewMy(@PathVariable String username) {
		List<TweetUser> tweet = viewTweetService.ViewMyTweet(username);
		return ResponseEntity.ok().body(tweet);
	}

	/*
	 * @GetMapping("/users/search/{username}") public List<TweetUser>
	 * search(@PathVariable String username) { return
	 * viewTweetService.search(username); }
	 */
	@DeleteMapping("/{username}/delete/{id}")
	public @ResponseBody String deleteTweet(@PathVariable String username,@PathVariable String id) {
		return viewTweetService.deleteTweet(username,id);
		
	}
	
	@PutMapping("/{username}/update/{id}")
	public ResponseEntity<TweetUser> updateTweet(@PathVariable String username , @PathVariable String id,@Valid @RequestBody TweetUser tweetdetails){
		TweetUser tweetupdate= viewTweetService.updateTweet(username,id,tweetdetails);
		return ResponseEntity.ok().body(tweetupdate);
	}
	
}
