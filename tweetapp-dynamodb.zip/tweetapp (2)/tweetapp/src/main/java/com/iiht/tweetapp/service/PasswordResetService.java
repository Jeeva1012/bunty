package com.iiht.tweetapp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.repository.LoginRepository;

@Service
public class PasswordResetService {
	
	@Autowired
	LoginRepository loginRepository;;

	public String resetPassword(String email,String newpassword) {
		
		
		RegisterUser user = loginRepository.findByEmail(email);
		boolean existingUser=user==null?true:false;
		//logger.info("Checking User Exist"+existingUser);
		if(!existingUser) {
		user.setPassword(newpassword);
		user.setConfirmPassword(newpassword);
		loginRepository.save(user);
		return "Password changed successfully";
		}else {
			return "User doesn't exit - Please register";
		}
		
	}
}
