
import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import Search from "./Search";
import { withRouter } from "react-router";
import { VscTwitter } from "react-icons/vsc";
import { AiOutlineSearch,AiOutlineLogout,AiFillProfile} from "react-icons/ai";
import { FaUsers} from "react-icons/fa";


class HeaderComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            username:'',
            search:'',
        result :[],
        show: false
            
            
        }
        
        this.logout = this.logout.bind(this);
        this.search = this.search.bind(this)
    }

    logout(){
        window.localStorage.removeItem("username");
        this.props.history.push('/viewTweetshome');
      }
      
        search(){
          
          const {show} = this.state
          this.setState({show: !show})
          
          window.localStorage.setItem("user",this.state.search)
        }
        changeHandler = (e) =>
          this.setState({ [e.target.name]: e.target.value });

         
    render() {
        const BarStyling = {width:"20rem",background:"#F2F1F9", border_color:"#073573", padding:"0.5rem"};
        const {search} = this.state
        return (
          
          <div className="App">
            <nav className="navbar navbar-expand-lg navbar-light fixed-top">
              <div className="container">
                <Link className="navbar-brand" to={"/allTweet"}><h5>TweetApp</h5><VscTwitter size="30px" color="#073573" /></Link>
                <div className="collapse navbar-collapse" id="navbarTogglerDemo02">

                  <ul className="navbar-nav ml-auto">

                    <li className="nav-item">
                      <Link className="nav-link" to={"/myTweet"}><AiFillProfile size="30px" color="#073573" />My Tweet</Link>&nbsp;&nbsp;&nbsp;
                    </li>

                    <li className="nav-item">

                      <Link className="nav-link" to={"/allUser"}><FaUsers size="30px" color="#073573" />Users</Link>&nbsp;&nbsp;&nbsp;
                    </li>

                    <li className="nav-item">

                      <input
                        style={BarStyling}
                        name="search"
                        value={search}
                        placeholder={"search Username"}
                        onChange={this.changeHandler}
                      />
                      <AiOutlineSearch size="30px" color="#073573" onClick={this.search} />&nbsp;&nbsp;&nbsp;
                      </li>

                    <li className="nav-item">
                      <AiOutlineLogout size="30px" color="#073573" onClick={() => this.logout()} /><h6>{window.localStorage.getItem("username")}</h6>

                    </li>

                  </ul>
                </div>
              </div>
            </nav>
            <br></br><br></br>
            {this.state.show && <Search />}
          </div>
        );
            }
        }

export default withRouter(HeaderComponent);