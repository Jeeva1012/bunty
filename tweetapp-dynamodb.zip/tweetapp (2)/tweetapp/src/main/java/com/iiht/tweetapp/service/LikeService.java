package com.iiht.tweetapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.repository.UserRepository;
import com.iiht.tweetapp.repository.ViewTweetRepository;

@Service
public class LikeService {

	@Autowired
	UserRepository userRepo;
	
	@Autowired
	ViewTweetRepository viewTweetRepo;
	
	TweetUser tweetuser;
	
	
	  public  TweetUser likeTweet(String username, String id) {

		 TweetUser user = viewTweetRepo.findByUsernameAndId(username,id);
		  user.setLike((user.getLike())+1);
		  tweetuser = viewTweetRepo.save(user);
		  return tweetuser;
	  }
	  
	  
	 
}
