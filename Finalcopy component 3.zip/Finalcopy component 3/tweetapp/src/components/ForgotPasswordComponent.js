import React, { Component } from "react";
import ApiService from "../service/ApiService.jsx";
import HeaderComponent from "./HeaderComponent.js";

class ForgotPassword extends Component {

    constructor(props){
        super(props);
        this.state ={
            username: '',
            new_password: '',
            message:'',
            error:''
        }
        this.updatePass = this.updatePass.bind(this);
    }

    changeHandler = (e) =>
    this.setState({ [e.target.name]: e.target.value });

    updatePass = (e) => {
        e.preventDefault();
        console.log(this.state)
       // let user = {username: this.state.username,password: this.state.password};
     

        //ApiService.loginUser(this.state.username,this.state.password)
       ApiService.forgot(this.state.username,this.state.new_password)
        .then(res => {
                console.log(res)
                this.setState({message:'Password changed successfully'})
               
               this.props.history.push('/login');
            }).catch(err=>{
                    this.setState({error:'Invalid username and password'})
                  
            })
    }


    render() {
        const {username,new_password} = this.state
        return (
            <div>
                <HeaderComponent/>
            <form className="auth-wrapper-login">
                <h3>Forgot Password</h3>
                
                <div className="form-group">
                    <label>Username</label>
                    <input type="email" className="form-control" placeholder="Enter Registered username" name="username" value={username}  onChange={this.changeHandler}/>
                </div>

                <div className="form-group">
                    <label>New Password</label>
                    <input type="password" className="form-control" placeholder="Enter new password" name="new_password" value={new_password}  onChange={this.changeHandler} />
                </div>

                <button type="submit" className="btn btn-primary btn-block" onClick={this.updatePass}>Submit</button>
                
            </form>
            </div>
        );
    }
}

export default ForgotPassword;