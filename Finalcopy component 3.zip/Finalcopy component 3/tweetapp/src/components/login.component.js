import React, { Component } from "react";
import ApiService from "../service/ApiService.jsx";
import HomeComponent from "./HomeComponent.js";

class Login extends Component {

    constructor(props){
        super(props);
        this.state ={
            username: '',
            password: '',
            error:''
        }
        this.loginUser = this.loginUser.bind(this);
    }

    changeHandler = (e) =>
    this.setState({ [e.target.name]: e.target.value });

    loginUser = (e) => {
        e.preventDefault();
        console.log(this.state)
        console.log(this.state.username);
        console.log(this.state.password);
       ApiService.login(this.state.username,this.state.password)
       
            .then(res => {
                console.log(res)
                window.localStorage.setItem("username", this.state.username);
               this.props.history.push('/allTweet');
            }).catch(err=>{
                    this.setState({error:'Invalid username and password'})
            })
    }


    render() {
        const {username,password,error} = this.state
        
        return (
            <div>
               <HomeComponent/>
               {error ? <div>{error}</div> : null }
            <form className="auth-wrapper-login">
                <h3>login</h3>

                <div className="form-group">
                    <label>Username</label>
                    <input type="email" className="form-control" placeholder="Enter email" name="username" value={username}  onChange={this.changeHandler}/>
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" placeholder="Enter password" name="password" value={password}  onChange={this.changeHandler} />
                </div>

                <button type="submit" className="btn btn-primary btn-block" onClick={this.loginUser}>Submit</button>
                <p className="forgot-password text-right">
                    Forgot <a href="/forgot">password?</a>
                </p>
            </form>
            </div>
        );
    }
}

export default Login;