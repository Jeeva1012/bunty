
package com.iiht.tweetapp.service;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	
	  @Autowired 
	  private AmazonDynamoDB amazonDynamoDB;
	 


	@Autowired
	private UserRepository userRepository;

	public String register(RegisterUser user) throws Exception {
		
		  dynamoDBMapper = new DynamoDBMapper(amazonDynamoDB);
		  
		  CreateTableRequest tableRequest = dynamoDBMapper
		  .generateCreateTableRequest(RegisterUser.class);
		  
		  tableRequest.setProvisionedThroughput( new ProvisionedThroughput(1L, 1L));
		  
		  TableUtils.createTableIfNotExists(amazonDynamoDB, tableRequest);
		 
		 
		
		final Logger logger = LoggerFactory.getLogger(this.getClass());
		RegisterUser registeruser=userRepository.findByEmail(user.getEmail());
		boolean existingUser=registeruser==null?true:false;
		logger.info("Checking UserAlready Exist"+existingUser);
		if(!existingUser) {
			throw new Exception("EmailId already Exist"); 
			
			}
		
		else {
			System.out.println(user);
		userRepository.save(user);
		
		
		}
		return "Register User successfully";
	}

	public Iterable<RegisterUser> getUser() {
		Iterable<RegisterUser> allUser = userRepository.findAll();
		return allUser;
	}
}
