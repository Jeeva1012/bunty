package com.iiht.tweetapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.service.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("api/v1.0/tweets")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/register")
	public String save(@RequestBody RegisterUser registerUser) throws Exception {
		
		return userService.register(registerUser);
	}
	
	
	  @GetMapping("/users/all") 
	  public Iterable<RegisterUser> getAllUser(){ 
		  return userService.getUser(); 
		  }
	  
	
	 
}
