package com.iiht.tweetapp.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.repository.ReplyRepository;
import com.iiht.tweetapp.repository.TweetRepository;
import com.iiht.tweetapp.repository.UserRepository;

@Service
public class PostTweetService {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	
	  @Autowired 
	  private AmazonDynamoDB amazonDynamoDB;
	 
	@Autowired
	TweetRepository tweetRepo;
	
	@Autowired
	ReplyRepository replyRepo;

	@Autowired
	UserRepository userRepo;

	public TweetUser postTweet(String username, TweetUser tweetuser) {
		
		dynamoDBMapper = new DynamoDBMapper(amazonDynamoDB);
		  
		  CreateTableRequest tableRequest = dynamoDBMapper
		  .generateCreateTableRequest(RegisterUser.class);
		  
		  tableRequest.setProvisionedThroughput( new ProvisionedThroughput(1L, 1L));
		  
		  TableUtils.createTableIfNotExists(amazonDynamoDB, tableRequest);
		 
		 

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String time = dtf.format(now);

		tweetuser.setUsername(username);
		tweetuser.setLike(0);
		tweetuser.setTime(time);

		return tweetRepo.save(tweetuser);
	

	}

}
