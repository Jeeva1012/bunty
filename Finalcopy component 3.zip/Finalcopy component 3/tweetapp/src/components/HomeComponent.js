import React, { Component } from "react";

import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Search from "./Search";
import { RiLoginCircleFill, RiRegisteredFill } from "react-icons/ri";
import { AiOutlineSearch } from "react-icons/ai";
import { VscTwitter } from "react-icons/vsc";

class HomeComponent extends Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      result: [],
      message: '',
      show: false
    }
    this.search = this.search.bind(this)


  }

  search() {

    const { show } = this.state
    this.setState({ show: !show })
    window.localStorage.setItem("user", this.state.username)
  }
  changeHandler = (e) =>
    this.setState({ [e.target.name]: e.target.value });

  render() {

    const BarStyling = { width: "20rem", background: "#F2F1F9", border_color: "#073573", padding: "0.5rem" };
    const { username } = this.state
    return (
      <div className="App">
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <Link className="navbar-brand" to={"/viewTweetshome"}><h5>TweetApp</h5><VscTwitter size="30px" color="#073573" /></Link>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item">
                  <Link className="nav-link" to={"/login"}><RiLoginCircleFill size="30px" color="#073573" />Login</Link>&nbsp;&nbsp;&nbsp;
                      </li>
                <li className="nav-item">
                  <Link className="nav-link" to={"/register"}><RiRegisteredFill size="30px" color="#073573" />Register</Link>&nbsp;&nbsp;&nbsp;
                      </li>

                <li className="nav-item">

                  <input
                    style={BarStyling}
                    name="username"
                    value={username}
                    placeholder={"search Username"}
                    onChange={this.changeHandler}
                  />
                  <AiOutlineSearch size="30px" color="#073573" onClick={this.search} />&nbsp;&nbsp;&nbsp;

                      </li>

              </ul>



            </div>

          </div>

        </nav>
        <br></br><br></br>
        {this.state.show && <Search />}
      </div>
    );


  }
}


export default HomeComponent;