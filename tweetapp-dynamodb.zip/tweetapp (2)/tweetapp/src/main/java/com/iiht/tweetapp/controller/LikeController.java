package com.iiht.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.service.LikeService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class LikeController {

	@Autowired
	LikeService likeService;
	
	@PutMapping("/{username}/like/{id}")
	public @ResponseBody TweetUser likeTweet(@PathVariable String username, @PathVariable String id) {
		 return likeService.likeTweet(username, id);
		 //return "Liked";
	}
}
