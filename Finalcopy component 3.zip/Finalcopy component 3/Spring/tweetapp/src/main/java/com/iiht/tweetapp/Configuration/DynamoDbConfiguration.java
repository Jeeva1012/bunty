/*
 * package com.iiht.tweetapp.Configuration;
 * 
 * import org.socialsignin.spring.data.dynamodb.repository.config.
 * EnableDynamoDBRepositories; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration;
 * 
 * import com.amazonaws.auth.AWSStaticCredentialsProvider; import
 * com.amazonaws.auth.BasicAWSCredentials; import
 * com.amazonaws.client.builder.AwsClientBuilder; import
 * com.amazonaws.services.dynamodbv2.AmazonDynamoDB; import
 * com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder; import
 * com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
 * 
 * @Configuration
 * 
 * @EnableDynamoDBRepositories(basePackages = "com.iiht.tweetapp.repository")
 * public class DynamoDbConfiguration {
 * 
 * public DynamoDBMapper dynamoDbMapper() { return new
 * DynamoDBMapper(amazonDynamoDb()); }
 * 
 * @Bean public AmazonDynamoDB amazonDynamoDb() {
 * 
 * return AmazonDynamoDBClientBuilder.standard().withEndpointConfiguration( new
 * AwsClientBuilder.EndpointConfiguration("dynamodb.us-east-2.amazonaws.com",
 * "us-east-2"
 * 
 * )
 * 
 * ).withCredentials(new AWSStaticCredentialsProvider( new
 * BasicAWSCredentials("AKIA6O3KGNCBQYCRVJ74",
 * "g8KCpNhzF0uTtZBEG7OesiGlcXeQyRlBT2Y/JdCR"))).build(); }
 * 
 * }
 */