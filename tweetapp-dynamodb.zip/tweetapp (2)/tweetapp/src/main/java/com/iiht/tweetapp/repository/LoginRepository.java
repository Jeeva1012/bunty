package com.iiht.tweetapp.repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.iiht.tweetapp.model.RegisterUser;

@EnableScan
@Repository
public interface LoginRepository extends CrudRepository<RegisterUser, String> {

	RegisterUser findByEmail(String email);
}
