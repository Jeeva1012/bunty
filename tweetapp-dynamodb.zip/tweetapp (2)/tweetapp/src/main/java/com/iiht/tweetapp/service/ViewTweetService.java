package com.iiht.tweetapp.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.repository.TweetRepository;
import com.iiht.tweetapp.repository.UserRepository;
import com.iiht.tweetapp.repository.ViewTweetRepository;

@Service
public class ViewTweetService {

	@Autowired
	ViewTweetRepository viewTweetRepo;
	
	
	
	@Autowired
	UserRepository userRepo;
	
	
	@Autowired
	TweetRepository tweetRepo;
	
	public Iterable<TweetUser> viewAllTweet() {
		
		
		Iterable<TweetUser> tweet = viewTweetRepo.findAll();
		
		for(int i=1;i<((List<TweetUser>) tweet).size();i++) {
	    try {
	    
	        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"); 
	        Date past = format.parse(((List<TweetUser>) tweet).get(i).getTime());
	        Date now = new Date();
	        long diff = now.getTime() - past.getTime(); 
	        long milliSecPerMinute = 60 * 1000; //Milliseconds Per Minute
	        long milliSecPerHour = milliSecPerMinute * 60; //Milliseconds Per Hour
	        long milliSecPerDay = milliSecPerHour * 24; //Milliseconds Per Day
	        long milliSecPerMonth = milliSecPerDay * 30; //Milliseconds Per Month
	        long milliSecPerYear = milliSecPerDay * 365; //Milliseconds Per Year
	        
	        if (diff < milliSecPerMinute) {
	            ((List<TweetUser>) tweet).get(i).setTimeAgo(TimeUnit.MILLISECONDS.toMillis(now.getTime() - past.getTime()) + " milliseconds ago");
	          }
	        
	        else if (diff < milliSecPerHour) {
	        	((List<TweetUser>) tweet).get(i).setTimeAgo(TimeUnit.MILLISECONDS.toMinutes(now.getTime() - past.getTime()) + " minutes ago");
	        }
	        else if (diff < milliSecPerDay) {
	        	((List<TweetUser>) tweet).get(i).setTimeAgo(TimeUnit.MILLISECONDS.toHours(now.getTime() - past.getTime()) + " hours ago");
	        }
	        else if (diff < milliSecPerMonth) {
	        	((List<TweetUser>) tweet).get(i).setTimeAgo(TimeUnit.MILLISECONDS.toDays(now.getTime() - past.getTime()) + " days ago");
	        }
	        else if(diff < milliSecPerYear) {
	        	//tweet.get(i).setTimeAgo(TimeUnit.MILLISECONDS.to(now.getTime() - past.getTime()) + " days ago");
	        	if (Math.round(diff / milliSecPerMonth) == 1) {
	        	      ((List<TweetUser>) tweet).get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerMonth)) + "  month ago... ");
	        	    } else {
	        	    	((List<TweetUser>) tweet).get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerMonth)) + "  months ago... ");
	        	    }
	        }
	        else {
	            if (Math.round(diff / milliSecPerYear) == 1) {
	            	((List<TweetUser>) tweet).get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerYear)) + " year ago...");
	            } else {
	            	((List<TweetUser>) tweet).get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerYear)) + " years ago...");
	            }
	          }
	        tweetRepo.save(((List<TweetUser>) tweet).get(i));
	        
	    }
	    catch (Exception j){
	        j.printStackTrace();
	    }
	    
	    
	 
		
		}
		return viewTweetRepo.findAll();
	}
	
	  public List<TweetUser> ViewMyTweet(String username){
	  
	  
	  List<TweetUser> tweetuser = viewTweetRepo.findAllByUsername(username); 
	  return tweetuser;
	  
	  
	  }
	 
	
	public String deleteTweet(String username,String id) {
		viewTweetRepo.deleteByusernameAndId(username, id);
			return "Deleted";
	}

	public TweetUser updateTweet(String username,String id,TweetUser tweetdetails) {
		TweetUser tweetUpdate = viewTweetRepo.findByUsernameAndId(username,id);
		tweetUpdate.setTweet(tweetdetails.getTweet());
		final TweetUser updatedTweet = viewTweetRepo.save(tweetUpdate);
		return updatedTweet;
	}

	/*
	 * public List<TweetUser> search(String username) {
	 * 
	 * return viewTweetRepo.searchByUsername(username);
	 * 
	 * }
	 */
}
